# Udacity-Project-1
Developed a static web page using HTML and CSS to showcase a custom trading card for German shepherd
